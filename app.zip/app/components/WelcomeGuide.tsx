"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";


export default function WelcomeGuide() {
  const [open, setOpen] = useState(false);
  

  useEffect(() => {
  const seen = sessionStorage.getItem("welcomeShown");

  if (!seen) {
    setOpen(true);
  }
}, []);

  const closeGuide = () => {
 sessionStorage.setItem("welcomeShown", "true");
  setOpen(false);
};
  

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/40 backdrop-blur-md p-6">

      <div className="w-full max-w-[620px] rounded-[6px] bg-[#FAF8F5] p-10 shadow-2xl">
        


<div className="py-8">

  <div className="flex flex-col items-center mb-12">

  <Image
    src="/tsf-logo.png"
    alt="The Skin Fix"
    width={220}
    height={60}
    className="h-auto w-[220px]"
  />

  <p className="mt-3 text-[12px] uppercase tracking-[0.25em] text-[#5B5047]">
    RECUPERACIÓN CUTÁNEA
  </p>

</div>

  <div className="relative h-[450px]">

    {/* Línea principal */}

    <motion.div
      initial={{ height: 0 }}
      animate={{ height: "100%" }}
      transition={{ duration: 15 }}
      className="absolute left-1/2 top-0 w-[2px] bg-[#D8C4B5]"
    />

    {/* Lucero viajero */}



    {/* PASO 1 */}

    <motion.div
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  transition={{ delay: 2.5 }}
  className="absolute left-[55%] top-0 relative"
>

  <span className="absolute -left-[235px] -top-[30px] text-[110px] font-light tracking-[-0.06em] text-[#D8C4B5]/15 select-none pointer-events-none leading-none">
  01
</span>
      

<h3 className="text-xs uppercase tracking-[0.25em] text-[#B98B72]">
        Explora
      </h3>

      <p className="mt-2 max-w-[220px] text-sm text-[#5B5047]">
        Navega por nuestra web y descubre como trabajamos
      </p>
    </motion.div>

    {/* PASO 2 */}

    <motion.div
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  transition={{ delay: 5.5 }}
  className="absolute left-[55%] top-[120px] relative"
>

  <span className="absolute -left-[245px] -top-[30px] text-[110px] font-light tracking-[-0.06em] text-[#D8C4B5]/15 select-none pointer-events-none leading-none">
  02
</span>
      

<h3 className="text-xs uppercase -mt-1 tracking-[0.25em] text-[#B98B72]">
        Elige tu nivel de acompañamiento
      </h3>

      <p className="mt-2 max-w-[220px] text-sm text-[#5B5047]">
        Haz click en <b><i>elige tu plan</i></b> para decidir cómo comenzar
      </p>
    </motion.div>

    {/* PASO 3 */}

    <motion.div
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  transition={{ delay: 9 }}
  className="absolute left-[55%] top-[240px] relative"
>

  <span className="absolute -left-[245px] -top-[30px] text-[110px] font-light tracking-[-0.06em] text-[#D8C4B5]/15 select-none pointer-events-none leading-none">
  03
</span>
      

<h3 className="mt-2 text-xs uppercase tracking-[0.25em] text-[#B98B72]">
        Contacta
      </h3>

      <p className="mt-2 max-w-[220px] text-sm text-[#5B5047]">
       Cuéntanos tu caso por WhatsApp, Email o Instagram
      </p>
    </motion.div>

    {/* PASO 4 */}

    <motion.div
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  transition={{ delay: 12 }}
  className="absolute left-[55%] top-[360px] relative"
>

  <span className="absolute -left-[245px] -top-[30px] text-[110px] font-light tracking-[-0.06em] text-[#D8C4B5]/15 select-none pointer-events-none leading-none">
  04
</span>
      

      <h3 className="mt-1 text-xs uppercase tracking-[0.25em] text-[#B98B72]">
        Recuperación
      </h3>

      <p className="mt-2 max-w-[220px] text-sm text-[#5B5047]">
        Diseñaremos el camino más adecuado para tu piel
      </p>
    </motion.div>

  </div>

  <button
    onClick={closeGuide}
    className="mt-10 w-full rounded-full bg-[#D0A48E] py-4 text-sm font-medium uppercase tracking-[0.2em] text-white"
  >
    Descubre
  </button>

</div>



        

      </div>

    </div>
  );
}
