"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import Image from "next/image";
import { TypeAnimation } from "react-type-animation"
import WelcomeGuide from "./components/WelcomeGuide"
import PlanesModal from "./PlanesModal";

export default function TheSkinFixWebsite() {
  const [mensaje, setMensaje] = useState("");
  const [open, setOpen] = useState(false)
  const [faqOpen, setFaqOpen] = useState<number | null>(0)
  const [cellsGlow, setCellsGlow] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [messageIndex, setMessageIndex] = useState(0)
  const messages = [
  "PRIMER CENTRO DE RECUPERACIÓN CUTÁNEA DE ESPAÑA",
  "TU PIEL SABE RECUPERARSE SOLA. NOSOTROS LA AYUDAMOS",
  "RECUPERAMOS LA BIOLOGÍA DE TU PIEL, NO SOLO SU ASPECTO",
];
  const [paused, setPaused] = useState(false)
  const [showPrice1, setShowPrice1] = useState(false)
const [showPrice2, setShowPrice2] = useState(false)
const [showPrice3, setShowPrice3] = useState(false)
const [showTerms, setShowTerms] = useState(false)
const [isMinimized, setIsMinimized] = useState(false);
const [position, setPosition] = useState(0)
const [dragging, setDragging] = useState(false)

const [positionGuiado, setPositionGuiado] = useState(0)
const [draggingGuiado, setDraggingGuiado] = useState(false)

const [positionClub, setPositionClub] = useState(0)
const [draggingClub, setDraggingClub] = useState(false)


// ---------- PLAN LIBRE ----------

const handleStart = () => {
  setDragging(true)
}

const handleMove = (e: any) => {
  if (!dragging) return

  const x = e.clientX || e.touches?.[0]?.clientX

  const slider = document.getElementById("plan-libre-slider")
  if (!slider) return

  const rect = slider.getBoundingClientRect()

  let newPosition = x - rect.left - 24

  if (newPosition < 0) newPosition = 0
  if (newPosition > 220) newPosition = 220

  setPosition(newPosition)
}

const handleEnd = () => {
  setDragging(false)

  if (position > 180) {
    window.open(
      "https://wa.me/34618820842?text=Hola,%20me%20interesa%20el%20PLAN%20LIBRE.%20%C2%BFCu%C3%A1ndo%20tendr%C3%ADais%20disponibilidad%3F",
      "_blank"
    )
  }

  setPosition(0)
}

// ---------- PLAN GUIADO ----------

const handleStartGuiado = () => {
  setDraggingGuiado(true)
}

const handleMoveGuiado = (e: any) => {
  if (!draggingGuiado) return

  const x = e.clientX || e.touches?.[0]?.clientX

  const slider = document.getElementById("plan-guiado-slider")
  if (!slider) return

  const rect = slider.getBoundingClientRect()

  let newPosition = x - rect.left - 24

  if (newPosition < 0) newPosition = 0
  if (newPosition > 220) newPosition = 220

  setPositionGuiado(newPosition)
}

const handleEndGuiado = () => {
  setDraggingGuiado(false)

  if (positionGuiado > 180) {
    window.open(
      "https://wa.me/34618820842?text=Hola,%20me%20interesa%20el%20PLAN%20GUIADO.%20%C2%BFCu%C3%A1ndo%20tendr%C3%ADais%20disponibilidad%3F",
      "_blank"
    )
  }

  setPositionGuiado(0)
}


// ---------- CLUB ----------

const handleStartClub = () => {
  setDraggingClub(true)
}

const handleMoveClub = (e: any) => {
  if (!draggingClub) return

  const x = e.clientX || e.touches?.[0]?.clientX

  const slider = document.getElementById("club-slider")
  if (!slider) return

  const rect = slider.getBoundingClientRect()

  let newPosition = x - rect.left - 24

  if (newPosition < 0) newPosition = 0
  if (newPosition > 220) newPosition = 220

  setPositionClub(newPosition)
}

const handleEndClub = () => {
  setDraggingClub(false)

  if (positionClub > 180) {
    window.open(
      "https://wa.me/34618820842?text=Hola,%20me%20interesa%20the%20skin%20fix%20CLUB.%20%C2%BFCu%C3%A1ndo%20tendr%C3%ADais%20disponibilidad%3F",
      "_blank"
    )
  }

  setPositionClub(0)
}
useEffect(() => {
  if (paused) return;

  const interval = setInterval(() => {
    setMessageIndex((prev) => (prev + 1) % messages.length);
  }, 6000);

  return () => clearInterval(interval);
}, [paused, messages.length]);


  return (
     <>
    <WelcomeGuide />
    <div className="min-h-screen bg-bg-white text-[#171412] font-sans overflow-x-hidden">

      {/* HERO */}
<section className="relative min-h-screen px-17 pt-38 pb-8">

        <div className="relative min-h-[70vh] overflow-hidden rounded-[4px]">

  <video
    src="/hero-video.mp4"
    autoPlay
    muted
    playsInline
    onLoadedMetadata={(e) => {
      e.currentTarget.currentTime = 19
    }}
    onEnded={(e) => {
      e.currentTarget.currentTime = 19
      e.currentTarget.play()
    }}
    className="absolute inset-0 w-full h-full object-cover object-[100%_50%]"
  />

</div>

       {/* 
<div className="fixed top-[32px] left-0 w-full h-[90px] bg-[#B4A89C]">
...
</div>
*/}

<div className="mx-9 fixed top-15 left-8 right-8 h-[32px] rounded-[4px] border border-[#D9D2CA] bg-transparent z-50 flex items-center justify-center">
<div className="h-[32px] flex items-center justify-center px-4 bg-transparent">
  <span className="text-[10px] tracking-[0.18em] text-[#6B635D]">
    {messages[messageIndex]}
  </span>

  <button
    onClick={() => setPaused(!paused)}
    className="absolute right-6 text-[#6B635D] text-sm"
  >
    {paused ? "▶" : "❚❚"}
  </button>
  </div>
</div>
        {/* HEADER */}
        <header className="fixed top-[80px] ml-12 left-0 w-full z-50 flex items-center justify-between h-[90px]">

          <div className="flex ml-15 -mt-1 items-center gap-4">
 <Image
   src="/newfavicon.png"
   alt="the skin fix"
   width={38}
   height={38}
   className="opacity-90"
 />


</div>
<div className="hidden md:flex items-center font-bold gap-7 text-[14px] uppercase tracking-[0.12em] text-[#000000] ml-auto mr-40">

  <Link
  href="/diagnostico"
  className="flex items-center transition-all duration-300 hover:scale-110 active:scale-90"
>
  Diagnóstico
</Link>

<Link
  href="/protocolo"
  className="flex items-center transition-all duration-300 hover:scale-110 active:scale-90"
>
  Protocolo
</Link>

<Link
  href="/seguimiento"
  className="flex items-center transition-all duration-300 hover:scale-110 active:scale-90"
>
  Seguimiento
</Link>

</div>
        </header>

        {/* CONTENT */}
        <div className="relative z-10 flex-1 flex flex-col justify-center pt-10 md:pt-1">

          <div className="max-w-5xl -mt-55">

            <h1
className="text-[48px] sm:text-[74px] md:text-[60px] leading-[0.90] tracking-[-0.03em] normal-case max-w-6xl text-[#2C2725]"
style={{ fontFamily: 'satoshi', fontWeight: 400 }}
>
            
            </h1>
           
          </div>

        </div>
{/* <div className="absolute bottom-0 left-0 w-full h-[180px] bg-gradient-to-b from-transparent to-[#FAF8F5]" /> */}
      </section>

      {/* CONDITIONS */}
      
  <section className="relative overflow-visible px-6 md:px-8 py-1">
  

  {/* <div className="absolute inset-0 bg-[#FAF8F5]/40 z-0" /> */}
  
{/* <div className="absolute inset-0 bg-[#FAF8F5]/40 z-0" /> */}
        

<div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20">

  <button
    onClick={() => setOpen(true)}
    onMouseEnter={() => setCellsGlow(true)}
  onMouseLeave={() => setCellsGlow(false)}
    className="relative z-10 rounded-full bg-[#B4A89C] opacity-0 animate-fadeIn
hover:bg-[#A6564D]
text-white
shadow-[0_0_80px_rgba(185,176,165,0.35)] px-10 py-4.5 text-[10px] uppercase tracking-[0.3em] text-white hover:bg-[#D9D2CC]
hover:tracking-[0.35em]
transition-all duration-500"
style={{ animationDelay: "3s" }}
  >
    ELIGE TU PLAN
  </button>

</div>

</section>
{/* ================= NUESTRA FILOSOFÍA ================= */}

<section className="bg-[#D9D2CA] text-[#F8F6F2] py-32">
  <div className="max-w-7xl mx-auto px-8 lg:px-16">

    <div className="grid lg:grid-cols-2 gap-24 items-center">


      {/* TEXTO */}

      <div className="max-w-[620px]">
        <h2
  className="
    -ml-9
    text-5xl
    lg:text-[64px]
    leading-[0.9]
    tracking-[-0.04em]
    font-white
    mt-6
    mb-10
    max-w-[620px]
    [text-shadow:0_0_18px_rgba(255,248,240,0.22),0_0_40px_rgba(255,248,240,0.10)]
  "
>
  Abrir paso<br />
   
  a la sencillez
</h2>

        <div className="space-y-7 text-[18px] leading-[36px] text-[#ffffff] -ml-8">

          <p>
The skin fix nace como una oportunidad para acabar con los dilemas de la piel hoy en día. Nuestro propósito es eliminar confusiones, simplificar su cuidado y lograr que cada persona entienda el proceso antes de comenzar. Como apasionada del estudio intensivo de la piel, tuve la oportunidad de desarrollar mi carrera junto a dermatólogos, médicos cirujanos y profesionales de la medicina estética en R.U., donde obtuve un enfoque que permite a todos mis clientes formar parte de ese cambio. Esa experiencia me enseñó a ver el cuidado de la piel de una forma diferente.

          </p>
<div className="-mt-4 flex justify-end">
  <Image
    src="/firmasinfondo.png"
    alt="Firma de Ana Guzmán"
    width={170}
    height={60}
    className="opacity-70 select-none pointer-events-none"
  />
</div>
         
        </div>
      
      </div>
<motion.div
  initial={{ opacity: 0, x: 80 }}
  whileInView={{ opacity: 1, x: 0 }}
  viewport={{ once: true, amount: 0.3 }}
  transition={{ duration: 2, ease: "easeOut" }}
  className="flex justify-center lg:justify-end lg:translate-x-8"
>
        <Image
          src="/fundadora1.JPG"
          alt="Fundadora The Skin Fix"
          width={520}
          height={650}
          className="w-full max-w-[520px] rounded-[6px] object-cover"
          priority
        />
      </motion.div>
    </div>

  </div>
</section>
      <section className="pt-28 pb-24">
  <div className="max-w-7xl mx-auto px-6">

    <div className="mb-20">
      
{/* <RESEÑAS> */}
      <h2 className="ml-1 text-[54px] leading-[0.9] font-black text-[#00000] mb-6">
        NUESTROS CLIENTES<br />
        
      </h2>

    
    </div>

    <div className="grid lg:grid-cols-3 gap-6">

      {/* CARD 1 */}
      <article className="
relative
overflow-hidden
rounded-[32px]
bg-[#D9D2CA]/40
backdrop-blur-2xl
border border-white/40
shadow-[0_20px_40px_rgba(180,168,156,0.12)]
p-10
h-full min-h-[420px]
">
        
        <p className="mt-6 text-[#7A6B60] leading-relaxed">
          En la primera cita me tranquilizó al momento, explicándome el proceso con todo detalle y cómo me beneficiaría según mi tipo de piel. Los resultados han sido increíbles en pocas semanas mi piel está más suave y luminosa, y las marcas del acné se van desvaneciendo con cada sesión. Me siento mucho más segura y ya no necesito maquillaje para salir.
        </p>

        <div className="mt-10 pt-6 border-t border-[#ffffff]">
          <p className="font-medium text-[#000000]">
            Cliente verificada
          </p>

        </div>
      </article>

      {/* CARD 2 */}
      <article className="
relative
overflow-hidden
rounded-[32px]
bg-[#D9D2CA]/40
backdrop-blur-2xl
border border-white/40
shadow-[0_20px_40px_rgba(180,168,156,0.12)]
p-10
h-full min-h-[420px]
">
        

        <p className="mt-6 text-[#7A6B60] leading-relaxed">
          Estoy probando el protocolo para acné y es una experiencia genial. Ana me hizo sentir cómodo desde el primer momento y sus conocimientos sobre la piel son impresionantes. Mi piel ha mejorado muchisimo.
        </p>

        <div className="mt-30 pt-6 border-t border-[#ffffff]">
          <p className="font-medium text-[#000000]">
            Maciej Z.
          </p>

        </div>
      </article>

      {/* CARD 3 */}
      <article className="
relative
overflow-hidden
rounded-[32px]
bg-[#D9D2CA]/40
backdrop-blur-2xl
border border-white/40
shadow-[0_20px_40px_rgba(180,168,156,0.12)]
p-10
h-full min-h-[420px]
">
        

        <p className="mt-6 text-[#7A6B60] leading-relaxed">
          Me regalaron una confianza increíble desde la primera cita, quedé impresionada con los resultados y con la atención recibida. Definitivamente la recomiendo.
        </p>

        <div className="mt-43 pt-6 border-t border-[#ffffff]">
          <p className="font-medium text-[#0000000]">
            Oana C.
          </p>

        
        </div>
      </article>

      {/* CARD 4 */}
      <article className="
relative
overflow-hidden
rounded-[32px]
bg-[#D9D2CA]/40
backdrop-blur-2xl
border border-white/40
shadow-[0_20px_40px_rgba(180,168,156,0.12)]
p-10
h-full min-h-[420px]
">
        

        <p className="mt-6 text-[#7A6B60] leading-relaxed">
          Llevo más de diez años visitando clínicas estéticas y desde que descubrí TSF no he cambiado. Profesional, muy fácil de tratar y los resultados hablan por sí solos. Cada sesión me voy con la sensación de que me cuidan de verdad.
        </p>

        <div className="mt-25 pt-6 border-t border-[#ffffff]">
          <p className="font-medium text-[#0000000]">
            Rosana G.
          </p>

      
        </div>
      </article>

      {/* CARD 5 */}
      <article className="
relative
overflow-hidden
rounded-[32px]
bg-[#D9D2CA]/40
backdrop-blur-2xl
border border-white/40
shadow-[0_20px_40px_rgba(180,168,156,0.12)]
p-10
h-full min-h-[420px]
">
        

        <p className="mt-6 text-[#7A6B60] leading-relaxed">
          Ana es increíble. Siempre consigue que me sienta super cómoda durante los tratamientos y los resultados desde que la visito son espectaculares.
        </p>

        <div className="mt-38 pt-6 border-t border-[#ffffff]">
          <p className="font-medium text-[#000000]">
            Sofia O.
          </p>

         
        </div>
      </article>

      {/* CARD 6 */}
      <article className="
relative
overflow-hidden
rounded-[32px]
bg-[#D9D2CA]/40
backdrop-blur-2xl
border border-white/40
shadow-[0_20px_40px_rgba(180,168,156,0.12)]
p-10
h-full min-h-[420px]
">
        

        <p className="mt-6 text-[#7A6B60] leading-relaxed">
          Pasé de tener una piel muy propensa al acné a una piel sin marcas gracias a estos protocolos. Ha estado ahí en cada paso de mi proceso y estoy muy feliz con los resultados.
        </p>

        <div className="mt-32 pt-6 border-t border-[#ffffff]">
          <p className="font-medium text-[#000000]">
            Ambar C.
          </p>

        
        </div>
      </article>

    </div>

  </div>
</section>

      {/* FAQ */}
<section className="px-4 md:px-17 py-0 mb-18 mt-4 bg-white">
  <div className="bg-[#F5F2EE] rounded-[6px] p-10 md:p-16 max-w-[2000px] mx-auto">

    <div className="grid lg:grid-cols-[0.85fr_1.15fr] gap-20 items-start">

      {/* IZQUIERDA */}
      <div>

        <div className="mb-8 max-w-3xl">
          <h2 className="-ml-6 text-[54px] sm:text-[74px] md:text-[60px] text-[#00000] leading-[0.96] tracking-[-0.05em] font-bold">
            FAQ
          </h2>
        </div>

        {[
          {
    question: '¿Qué es un centro de recuperación cutánea?',
    answer:
      'Es un espacio especializado en restaurar el equilibrio natural de la piel. En lugar de centrarnos únicamente en tratamientos o productos, trabajamos para que la piel vuelva a funcionar de forma saludable y autónoma.'
  },
  {
    question: '¿Es normal que mi piel empeore aunque esté usando buenos productos?',
    answer:
      'Sí. Un buen producto no garantiza buenos resultados si no responde a las necesidades reales de tu piel. En muchos casos, el problema no está en la calidad de los productos, sino en la combinación, la frecuencia de uso o la incapacidad de la piel para tolerarlos en ese momento.'
  },
  {
    question: '¿Por qué mi piel se irrita con casi todo?',
    answer:
      'Porque una piel sensibilizada pierde parte de su capacidad para tolerar estímulos cotidianos. Cuando la barrera cutánea está alterada, ingredientes que antes eran bien tolerados pueden provocar molestias, rojeces o inflamación.'
  },
  {
    question: '¿Cuánto tiempo tarda realmente una piel en recuperarse?',
    answer:
      'Depende del problema, del tiempo que lleve presente y del estado general de la piel. La recuperación real rara vez ocurre en días o semanas. Aunque es frecuente notar mejoría desde las primeras semanas, restaurar el equilibrio cutáneo requiere constancia y un enfoque adaptado a cada persona.'
  },
  {
    question: '¿Necesito una rutina con muchos productos para mejorar?',
    answer:
      'No. Una piel sana no debería depender de una rutina interminable. Nuestro objetivo es identificar lo que realmente aporta valor y eliminar todo aquello que añade complejidad sin aportar beneficios reales.'
  },
  {
    question: '¿Por qué mi acné vuelve una y otra vez?',
    answer:
      'Porque muchas estrategias consiguen reducir temporalmente los brotes sin abordar los factores que los mantienen activos. Mientras esos factores sigan presentes, la piel tenderá a repetir los mismos patrones.'
  },
  {
    question: '¿La rosácea puede mejorar de forma estable?',
    answer:
      'Aunque la rosácea no tiene una cura definitiva, muchas personas consiguen reducir significativamente la frecuencia e intensidad de los brotes cuando aprenden a comprender los desencadenantes de su piel y a respetar sus límites biológicos.'
  }
        ].map((faq, index) => (

          <div
            key={index}
            className="border-b border-black/5 py-2 md:py-8"
          >

            <button
              onClick={() => setFaqOpen(faqOpen === index ? null : index)}
              className="w-full flex items-center justify-between gap-6 text-left"
            >

              <span className="text-[16px] md:text-[18px] tracking-[-0.03em] font-black text-[#5E534A]">
                {faq.question}
              </span>

              <span className="text-[22px] text-[#B4A89C]">
                {faqOpen === index ? "−" : "+"}
              </span>

            </button>

            {faqOpen === index && (
              <p className="max-w-2xl text-[14px] md:text-[15px] leading-relaxed text-[#B4A89C] mt-6">
                {faq.answer}
              </p>
            )}

          </div>

        ))}

      </div>

      {/* DERECHA */}
      <div className="hidden lg:block sticky top-28 mt-6">

        <img
          src="/FAQfoto.jpeg"
          alt="The Skin Fix"
          className="w-full rounded-[34px] object-cover"
        />

      </div>

    </div>

  </div>
</section>

{open && (

<PlanesModal
  open={open}
  setOpen={setOpen}
  showTerms={showTerms}
  setShowTerms={setShowTerms}
  showPrice1={showPrice1}
  setShowPrice1={setShowPrice1}
  showPrice2={showPrice2}
  setShowPrice2={setShowPrice2}
  showPrice3={showPrice3}
  setShowPrice3={setShowPrice3}
  position={position}
  positionGuiado={positionGuiado}
  positionClub={positionClub}
  handleMove={handleMove}
  handleEnd={handleEnd}
  handleStart={handleStart}
  handleMoveGuiado={handleMoveGuiado}
  handleEndGuiado={handleEndGuiado}
  handleStartGuiado={handleStartGuiado}
  handleMoveClub={handleMoveClub}
  handleEndClub={handleEndClub}
  handleStartClub={handleStartClub}
/>
)}
      
      <section className="relative py-2 pb-40 overflow-hidden">

  {/* Marca de agua */}
  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
    <span
      className="select-none text-[160px] -translate-y-8 font-black tracking-[-0.002em] text-[#D9D2CA]/14"
      style={{ fontFamily: "satoshi" }}
    >
      HORARIO
    </span>
  </div>

  {/* Contenido */}
  <div className="relative z-10 max-w-6xl mx-auto translate-y-11 text-center">

    <p
      className="text-[16px] font-bold text-[#C69178]"
      style={{ fontFamily: "satoshi" }}
    >
      LUNES A VIERNES 10:00 – 20:00
    </p>

    <p
      className="mt-2 text-[15px] text-[#C69178]"
      style={{ fontFamily: "satoshi" }}
    >
      SÁBADOS CON CITA PREVIA
    </p>

  </div>
</section>
<footer className="relative rounded-[6px] mx-2 md:mx-17 mb-17 mt-1 h-[300px] overflow-hidden">
  <img
  src="/TSFtapiz1.png"
  alt="TSF Tapiz"
  className="absolute inset-0 w-full h-full object-cover opacity-10 brightness-[1.02] contrast-[1.05]"
/>

  <div className="relative z-10 flex h-full items-end justify-between px-8 pb-8 text-[#5E534A]">
    <div>
  <Image
  src="/tsf-logo.png"
  alt="The Skin Fix"
  width={150}
  height={52}
  className="h-[40px] w-auto"
/>

  <p className="text-sm text-[#000000] tracking-[0.13em] text-[8px] mt-2">
    RECUPERACIÓN CUTÁNEA
  </p>
</div>



    

<div className="flex gap-6 text-sm text-[#C69178]">
  <a href="/terminos">TÉRMINOS</a>
  <a href="/privacidad">PRIVACIDAD</a>
  <a href="/cookies">COOKIES</a>

  
</div>
  </div>
  
</footer>
<form
name="consulta"
  method="POST"
  data-netlify="true"
  className={`
fixed
bottom-6
right-6
z-50
w-[320px]
rounded-[22px]
border
border-white/25
text-[#FFF8F0]
backdrop-blur-xl
p-6
shadow-[0_18px_45px_rgba(0,0,0,0.12),inset_0_1px_1px_rgba(255,255,255,0.65)]
overflow-hidden
transition-all
duration-300
hover:-translate-y-[2px]
${isMinimized
  ? "bg-[#C69178]/85 border border-white/40 backdrop-blur-2xl shadow-[0_2px_8px_rgba(120,90,60,.10),inset_0_1px_1px_rgba(255,255,255,.65)]"
  : "bg-[#C9A88F]/30"
}
${isMinimized ? "h-[50px] rounded-[24px]" : "h-auto"}
`}
>
  <div className="flex items-center justify-between mb-5">

  {isMinimized ? (
  <div className="group flex items-center gap-3 -mt-[3px] -translate-y-[3px]">
    <div className="relative w-2.5 h-2.5 rounded-full bg-[#6DDC5A] shadow-[0_0_14px_rgba(109,220,90,.9)] translate-y-[-4px]" />

    <div className="-translate-y-1.5">
      <p className="text-[16px] font-semibold tracking-[0.01em] text-[#FFFFFF]">
        Ana
      </p>
    </div>
  </div>


  ) : (
    <div className="flex items-center gap-3 -mt-[3px]">
      <div className="w-2.5 h-2.5 rounded-full bg-[#6DDC5A] shadow-[0_0_12px_rgba(109,220,90,.8)] translate-y-[-3px]" />

      <div className="-translate-y-1">
        <p className="text-[16px] font-bold text-[#ffffff]">
          Ana
        </p>
      </div>
    </div>
  )}

  <button
    type="button"
    onClick={() => setIsMinimized(!isMinimized)}
    className="absolute right-6 top-2.5 text-xl text-[#FFF8F0]"
  >
    {isMinimized ? "+" : "−"}
  </button>

</div>

<p className="text-[15px] text-[#ffffff] leading-relaxed">
  Hola! Es un placer tenerte por aqui. Antes de empezar, me gustaría entender mejor tu caso, indícame:
</p>

<ul className="mt-6 space-y-2 text-[13px] text-[#ffffff]">
  <li><em>Qué te preocupa de tu piel</em></li>
  <li><em>Desde cuándo ocurre</em></li>
  <li><em>Qué has probado hasta ahora</em></li>
</ul>

<div className="h-6"></div>

<textarea
  value={mensaje}
  onChange={(e) => setMensaje(e.target.value)}
  placeholder=""
  className="
    w-full
    h-[95px]
    rounded-2xl
    bg-white/35
    backdrop-blur-md
    border
    border-white/40
    p-4
    text-[15px]
    text-[#3A352F]
    placeholder:text-[#8C8177]
    outline-none
    resize-none
    shadow-[inset_0_1px_2px_rgba(255,255,255,0.7)]
  "
/>

<button
  type="button"
  onClick={() => {
    window.open(
      `https://wa.me/34618820842?text=${encodeURIComponent(mensaje)}`,
      "_blank"
    );
  }}
  className="
  mt-4
  w-full
  rounded-[18px]
  bg-[#C69178]
  py-3
  text-white
  text-[11px]
  font-semibold
  uppercase
  tracking-[0.24em]
  border
  border-white/35
  shadow-[0_10px_24px_rgba(201,168,143,0.28),inset_0_1px_1px_rgba(255,255,255,0.35)]
  transition-all
  duration-300
  hover:bg-[#D3B39C]
  hover:-translate-y-[2px]
  hover:shadow-[0_16px_34px_rgba(201,168,143,0.42),inset_0_1px_1px_rgba(255,255,255,0.45)]
  active:translate-y-0
  active:shadow-[0_6px_16px_rgba(201,168,143,0.25),inset_0_2px_4px_rgba(0,0,0,0.08)]
"
>
  ENVIAR
</button>
</form>
</div>

</>

)
}