"use client";

import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";import Image from "next/image";
import Link from "next/link";
export default function DiagnosticoPage() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [activeMetric, setActiveMetric] = useState("Barrera cutánea");

const metricDescriptions: Record<string, string> = {
  "Regulación del sebo":
    "Valoramos cómo produce y distribuye el sebo para evitar tratar un exceso o una carencia de forma incorrecta.",
  "Textura":
    "Detectamos irregularidades que condicionan la respuesta del tratamiento.",
  "Inflamación":
    "Identificamos inflamación activa antes de aplicar estímulos que puedan empeorarla.",
  "Hidratación":
    "Medimos cómo retiene agua tu piel y cómo responderá al protocolo.",
  "Barrera cutánea":
    "Es el parámetro que determina la tolerancia y la recuperación de cualquier tratamiento.",
  "Sensibilidad":
    "Ajustamos la intensidad según la reactividad real de tu piel.",
  "Luminosidad":
    "Analizamos la calidad óptica de la piel como indicador biológico.",
  "Renovación celular":
    "Estimamos el ritmo de renovación para elegir el protocolo adecuado.",
  "Pigmentación":
    "Diferenciamos el comportamiento de las manchas antes de intervenir.",
  "Fotoenvejecimiento":
    "Valoramos el impacto acumulado del sol sobre la piel.",
};

useEffect(() => {
  const timer = setTimeout(() => {
    videoRef.current?.play();
  }, 7000);
const dots = Array.from({ length: 220 }, (_, i) => ({
  id: i,
  x: Math.random() * 110,
  y: Math.random() * 140,
}));
  return () => clearTimeout(timer);
}, []);
  const indicadores = [
    {
      
      title: "Función\nbarrera",
      description:
        "Analizamos la capacidad de la piel para protegerse y mantener el equilibrio.",
    },
    {
      
      title: "Estado\ninflamatorio",
      description:
        "Observamos signos de inflamación visibles y subclínicos que condicionan la recuperación.",
    },
    {
      
      title: "Nivel de\nhidratación",
      description:
        "Valoramos la reserva hídrica y la capacidad de la piel para conservarla.",
    },
    {
      
      title: "Sensibilidad\ncutánea",
      description:
        "Identificamos el grado de reactividad para adaptar cualquier tratamiento con seguridad.",
    },
  ];
  return (
    <main className="py-10 py-10">
      <Link
  href="/"
  className="ml-18 mt-9 inline-flex -translate-y-8 items-center text-[14px] font-bold uppercase tracking-[0.2em] text-black transition-all duration-300 hover:scale-110 active:scale-90"
>
  INICIO
</Link>
<section className="mt-8">
  <div className="max-w-[1300px] mx-auto px-8">
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 1.1 }}
      className="relative overflow-hidden rounded-[6px]"
    >
      <motion.div
  initial={{ opacity: 0, scale: 0.98 }}
  whileInView={{ opacity: 1, scale: 1 }}
  viewport={{ once: true }}
  transition={{ duration: 1.1 }}
  className="relative overflow-hidden rounded-[6px]"
>
  <video
  ref={videoRef}
  autoPlay
  muted
  loop
  playsInline
  preload="auto"
  className="w-full aspect-[16/9] object-cover"
>
    <source
      src="/diagnostico/cosmos_263634419.mp4"
      type="video/mp4"
    />
  </video>

  {/* Oscurece ligeramente el vídeo para que el texto respire */}
  <div className="absolute inset-0 bg-black/40" />

  {/* Texto editorial */}
  <div className="absolute inset-0 flex items-center justify-center px-12">
    <div className="max-w-[980px] text-center">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="text-white text-[34px] md:text-[44px] leading-[1.2] font-black"
      >
        Antes de iniciar cualquier protocolo medimos los parámetros que revelan
        el estado real de tu piel. Durante este paso sabremos si tu piel está lista para tratar o no.
      </motion.h2>

     
    </div>
  </div>
</motion.div>

      
    </motion.div>
  </div>
</section>
  <div className="max-w-[1350px] mx-auto px-8">
    <div className="overflow-hidden rounded-[6px] bg-[#FAF8F5]">
    <section className="py-24">
  <div className="max-w-[1100px] mx-auto px-8 text-center">

    <p className="mt-8 text-[18px] leading-[1.8] text-[#6F6863] max-w-[720px] mx-auto">
      Antes de recomendar cualquier protocolo analizamos diez parámetros que determinan el estado real de tu piel.
    </p>

  </div>

  <div className="max-w-[1200px] mx-auto px-8 mt-16">

    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">

      {[
        "Regulación del sebo",
        "Textura",
        "Inflamación",
        "Hidratación",
        "Barrera cutánea",
        "Sensibilidad",
        "Luminosidad",
        "Renovación celular",
        "Pigmentación",
        "Fotoenvejecimiento",
      ].map((item) => (
        <button
          key={item}
          onMouseEnter={() => setActiveMetric(item)}
          onClick={() => setActiveMetric(item)}
          className={`rounded-full border px-5 py-4 text-[12px] uppercase tracking-[0.14em] transition-all duration-300 ${
            activeMetric === item
              ? "bg-[#C69178] border-[#C69178] text-white"
              : "bg-white border-[#E6DED8] text-[#5E5652] hover:border-[#C69178] hover:-translate-y-[2px]"
          }`}
        >
          {item}
        </button>
      ))}
    </div>

    <motion.div
      key={activeMetric}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: .35 }}
      className="mt-12 rounded-[8px] bg-white p-10 border border-[#E8E1DB]"
    >

      <p className="uppercase tracking-[0.35em] text-[11px] text-[#A88A7A]">
        Analizando
      </p>

      <h3 className="mt-3 text-[32px] font-black">
        {activeMetric}
      </h3>

      <p className="mt-5 text-[17px] leading-[1.9] text-[#5E5652] max-w-[700px]">
        {metricDescriptions[activeMetric]}
      </p>

    </motion.div>

  </div>
</section>
<section className="pt-24 pb-24">

  <div className="max-w-7xl mx-auto px-8">

    <div className="grid lg:grid-cols-2 gap-24 items-center">

      <motion.div
        initial={{ opacity:0,y:40 }}
        whileInView={{ opacity:1,y:0 }}
        viewport={{ once:true }}
        transition={{ duration:1 }}
      >

        <p className="uppercase tracking-[0.35em] text-[11px] text-[#A88A7A]">
          Lo que ocurre durante tu cita
        </p>

        <h2 className="mt-6 text-[34px] md:text-[50px] leading-[1.05] font-black">
          No buscamos un problema.
          <br />
          Buscamos el patrón.
        </h2>

        <p className="mt-8 text-[18px] leading-[1.9] text-[#5E5652]">
          El diagnóstico no consiste en decir si tienes manchas o acné. Consiste en entender por qué tu piel responde como responde y decidir si está preparada para recibir un protocolo o necesita estabilizarse antes.
        </p>

      </motion.div>

      <motion.div
        initial={{ opacity:0,y:40 }}
        whileInView={{ opacity:1,y:0 }}
        viewport={{ once:true }}
        transition={{ duration:1 }}
      >

        <div className="relative w-[450px] h-[550px] overflow-hidden">

          <img
            src="/diagnostico/diagnostico.png"
            alt="Diagnóstico"
            className="w-full h-full object-cover -ml-10"
          />

          <motion.div
            className="absolute top-0 bottom-0 w-[2px]"
            style={{
              background:"linear-gradient(to bottom,transparent,rgba(255,255,255,.95),transparent)",
              boxShadow:"0 0 18px rgba(255,255,255,.8)"
            }}
            initial={{ left:"-5%" }}
            animate={{ left:"105%" }}
            transition={{
              duration:5,
              repeat:Infinity,
              ease:"linear",
              repeatDelay:1
            }}
          />

        </div>

      </motion.div>

    </div>

  </div>

</section>
<section className="pb-28">

  <div className="max-w-[980px] mx-auto px-8">

    <motion.div
      initial={{ opacity:0,y:40 }}
      whileInView={{ opacity:1,y:0 }}
      viewport={{ once:true }}
      transition={{ duration:1 }}
      className="rounded-[8px] bg-white border border-[#E8E1DB] p-12"
    >

      <p className="uppercase tracking-[0.35em] text-[11px] text-[#A88A7A]">
        Lo que te llevas
      </p>

      <div className="grid md:grid-cols-[120px_1fr] gap-10 items-start mt-6">

        <div className="text-[72px] font-black leading-none text-[#C69178]">
          €20
        </div>

        <div>

          <h3 className="text-[34px] leading-[1.05] font-black">
            No estás pagando una consulta.
          </h3>

          <h3 className="text-[34px] leading-[1.05] font-black text-[#C69178]">
            Estás evitando tratar tu piel a ciegas.
          </h3>

          <p className="mt-8 text-[18px] leading-[1.9] text-[#5E5652]">
            Saldrás con un mapa de tu piel, una explicación clara de cómo responde y la certeza de si está preparada para comenzar un protocolo o necesita estabilizarse primero.
          </p>

        </div>

      </div>

    </motion.div>

  </div>

</section>
    </div> {/* Fin del bloque beige */}
  </div>   {/* Fin del contenedor principal */}
  {/* FOOTER CTA */}

  <section className="mt-24 mb-8">
    <div className="relative max-w-[1350px] mx-auto px-8 overflow-hidden">
      <div className="rounded-[8px] bg-[#FAF8F5] px-20 py-12">

        <div className="mt-12 flex justify-center">
          <button
            className="
              rounded-full
              bg-[#C69178]
              px-12
              py-4
              text-[13px]
              font-medium
              uppercase
              tracking-[0.25em]
              text-white
              border
              border-white/20
              transition-all
              duration-300
              ease-out
              shadow-[inset_0_1px_0_rgba(255,255,255,0.18),0_14px_35px_rgba(94,74,58,0.18)]
              hover:bg-[#DBA185]
              hover:-translate-y-[2px]
              hover:shadow-[inset_0_1px_0_rgba(255,255,255,0.25),0_22px_45px_rgba(94,74,58,0.28)]
            "
          >
            ELEGIR PLAN
          </button>
        </div>

        <div
          className="mt-20 pt-8 flex items-center justify-between text-[13px] tracking-[0.15em] text-[#8E847F]"
          style={{ borderTop: "3px solid rgba(255,255,255,.75)" }}
        >
          <Image
            src="/newfavicon.png"
            alt="the skin fix"
            width={42}
            height={42}
            className="opacity-90"
          />

          <div className="flex gap-10">
            <a
              href="/diagnostico"
              className="uppercase tracking-[0.18em] text-[#000000] hover:opacity-70 transition"
            >
              Diagnóstico
            </a>

            <a
              href="/protocolo"
              className="uppercase tracking-[0.18em] hover:opacity-70 transition"
            >
              Protocolo
            </a>

            <a
              href="/seguimiento"
              className="uppercase tracking-[0.18em] hover:opacity-70 transition"
            >
              Seguimiento
            </a>
          </div>
        </div>

      </div>
    </div>
    
  </section>

</main>
 );
}