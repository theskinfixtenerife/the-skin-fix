"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import Image from "next/image";
import { Waves, Droplet, Bandage, CircleDot, Sparkles, ShieldCheck } from "lucide-react";
import Link from "next/link";
export default function ProtocoloPage() {
  const [showPrices, setShowPrices] = useState(false);
const [showInfo, setShowInfo] = useState(false);
const [activeBoost, setActiveBoost] = useState(0);
const boostBar = [
];
  const protocolos = [
    
    {
      number: "01",
      title: "acné y piel congestionada",
      description:
        "Para pieles que presentan brotes recurrentes, inflamación o tendencia a la obstrucción.",
    },
    {
      number: "02",
      title: "rosácea y sensibilidad",
      description:
        "Para pieles reactivas que experimentan enrojecimiento, ardor o intolerancia frecuente.",
    },
    {
      number: "03",
      title: "hidratación y luminosidad",
      description:
        "Para pieles apagadas, deshidratadas o con sensación constante de tirantez.",
    },
    {
      number: "04",
      title: "textura\ny poros",
      description:
        "Para pieles que presentan irregularidades visibles en la superficie cutánea.",
    },
    {
      number: "05",
      title: "manchas y pigmentación",
      description:
        "Para pieles con alteraciones del tono o pigmentación desigual.",
    },
    {
      number: "06",
      title: "cicatrices y marcas",
      description:
        "Para pieles que presentan secuelas visibles tras procesos inflamatorios.",
    },
    {
      number: "07",
      title: "elasticidad y regeneración",
      description:
        "Para pieles que han perdido firmeza, densidad o capacidad de recuperación.",
    },
  ];

  return (
    
    <main className="bg-white min-h-screen pt-8 pb-24 px-6 relative overflow-hidden">
       <Link
  href="/"
  className="ml-8 mt-10 inline-flex -translate-y-8 items-center text-[14px] font-bold uppercase tracking-[0.2em] text-black transition-all duration-300 hover:scale-110 active:scale-90"
>
  INICIO
</Link>
        <div
  className="absolute left-[450px] top-[120px] pointer-events-none"
  style={{ opacity: 0.08 }}
>
 
</div>
      <div className="max-w-[1300px] mx-auto rounded-[6px] bg-[#F5F2EE] px-16 py-20">
        
        <div className="mt-0 mb-20 max-w-3xl relative">
            <div
 
>

</div>
<div className="relative z-10"></div>
          

          <h1 className="ml-16 translate-y-[60px] text-[48px] md:text-[72px] leading-[0.95] font-black tracking-[-0.04em] text-[#000000]">
  MÉTODO
            <Image
              src="/tsf-logo.png"
              alt="The Skin Fix"
              width={150}
              height={52}
              className="h-[40px] w-auto"
            />
            <br />
           
          </h1>
<div
  className="absolute right-40 -top-10 hidden lg:block"
  style={{ right: "-22px" }}
>
  <img
    src="/CHICABELLA.webp"
    alt="Modelo"
    className="w-[650px] h-[300px] object-cover translate-x-100"
  />
</div>
          
          <div className="max-w-[400px] mx-auto">
 
</div>
        </div>

<motion.div
  initial={{
    opacity: 0,
    y: 12,
    filter: "blur(6px)",
  }}
  animate={{
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
  }}
  transition={{
    duration: 0.8,
    delay: 0.35,
    ease: [0.16, 1, 0.3, 1],
  }}
  className="mt-25 ml-2"
>
  <button className="inline-flex items-center gap-3 text-[#C69178] uppercase tracking-[0.30em] text-[20px] font-bold hover:opacity-70 transition">
    SELECCIONA UN PROTOCOLO

    <motion.svg
      initial={{ y: -3, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{
        duration: 0.5,
        delay: 0.65,
        ease: [0.16, 1, 0.3, 1],
      }}
      xmlns="http://www.w3.org/2000/svg"
      width="18"
      height="18"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth="1.8"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M19 9l-7 7-7-7"
      />
    </motion.svg>
  </button>
</motion.div>
        <motion.div
  className="grid md:grid-cols-2 xl:grid-cols-4 gap-6 translate-y-10"
  initial="hidden"
  animate="show"
  variants={{
    hidden: {},
    show: {
      transition: {
        delay: 1,
        staggerChildren: 0.08,
      },
    },
  }}
>
  {protocolos.map((item) => (
    <motion.a
      href={`https://wa.me/34618820842?text=${encodeURIComponent(
        `Me gustaría probar el protocolo "${item.title}". ¿Cuando tendrías una cita disponible?`
      )}`}
      target="_blank"
      rel="noopener noreferrer"
      key={item.number}
      variants={{
        hidden: {
          opacity: 0,
          y: 18,
          filter: "blur(6px)",
        },
        show: {
          opacity: 1,
          y: 0,
          filter: "blur(0px)",
        },
      }}
      transition={{
        duration: 0.55,
        ease: [0.16, 1, 0.3, 1],
      }}
      className="
bg-[#ffffff]/80
rounded-[32px]
border border-white/50
shadow-[0_10px_30px_rgba(0,0,0,0.045)]
backdrop-blur-sm
p-10
h-[300px]
flex
flex-col
transition-all
duration-500
hover:-translate-y-1
hover:border-white/80
hover:shadow-[0_0_0_1px_rgba(255,255,255,0.7),0_20px_45px_rgba(0,0,0,0.08)]
"
    >
      <p className="text-[#C69178] text-3xl mb-4">{item.number}</p>

      <h2
        className="text-[28px] leading-tight text-[#5E534A] mb-2 min-h-[80px] whitespace-pre-line"
        style={{ fontFamily: "satoshi" }}
      >
        {item.title}
      </h2>

      <p className="text-[#B3A99D] text-sm leading-relaxed">
        {item.description}
      </p>
    </motion.a>
  ))}

  <motion.div
    variants={{
      hidden: {
        opacity: 0,
        y: 18,
        filter: "blur(6px)",
      },
      show: {
        opacity: 1,
        y: 0,
        filter: "blur(0px)",
      },
    }}
    transition={{
      duration: 0.55,
      ease: [0.16, 1, 0.3, 1],
    }}
    className="
bg-[#F8F6F3]/80
rounded-[32px]
border border-white/50
shadow-[0_0_0_1px_rgba(255,255,255,0.35),0_8px_30px_rgba(0,0,0,0.03)]
backdrop-blur-sm
p-7
h-[420px]
flex
flex-col
transition-all
duration-500
hover:-translate-y-1
hover:border-white/80
hover:shadow-[0_0_0_1px_rgba(255,255,255,0.7),0_20px_45px_rgba(0,0,0,0.08)]
"
  >
    <div>
      <h2
        className="text-[25px] mt-5 leading-none font-medium text-[#000000] mt-12 mb-12 text-center"
        style={{ fontFamily: "satoshi" }}
      >
        ¿no sabes por dónde empezar?
      </h2>

      <p className="text-[15px] mt-8 leading-relaxed text-[#666] text-center">
        En el <strong>PLAN GUIADO</strong> estudiamos tu caso antes de comenzar
        y te indicamos el protocolo más adecuado para tus objetivos.
      </p>
    </div>

    <a
      href="https://wa.me/34618820842?text=Hola,%20quiero%20reservar%20mi%20diagnóstico%20.%20¿Qué%20días%20tienes%20disponibles?"
      target="_blank"
      rel="noopener noreferrer"
      className="mt-8 mx-auto rounded-full bg-[#C69178] hover:bg-[#DBA185] px-8 py-4 text-white uppercase tracking-[0.2em] text-[11px] w-fit inline-block"
    >
      Reservar
    </a>
  </motion.div>
</motion.div>
        <div className="mt-20 ml-2 flex justify-start">
  <button
    onClick={() => setShowPrices(!showPrices)}
    className="text-[20px] uppercase tracking-[0.30em] font-bold text-[#D8A185] hover:opacity-70 transition"
    style={{ fontFamily: "Satoshi" }}
  >
    Consulta su precio
  </button>
</div>
<div className="mt-12 ml-2">
  
</div>

<div
  className={`overflow-hidden transition-all duration-500 ease-out ${
    showPrices
      ? "max-h-[1200px] opacity-100"
      : "max-h-0 opacity-0"
  }`}
>
  <div className="mt-4 mb-20 max-w-[1280px] mx-auto">
    <img
      src="/preciosnueva.png"
      alt="Tabla de precios"
      className="w-full max-w-[800px] mx-auto rounded-[8px]"
    />
  </div>
</div>
<h2
  className="ml-2 mt-10 text-[20px] uppercase tracking-[0.30em] font-bomld text-[#D8A285]"
  style={{ fontFamily: "Satoshi" }}
>
  CONTINÚA TU RECUPERACIÓN
</h2>
  <motion.div
  initial="hidden"
  whileInView="visible"
  viewport={{ once: true, amount: 0.3 }}
  variants={{
    visible: {
      transition: {
        staggerChildren: 0.18,
      },
    },
  }}
  className="mt-10"
>
  <div className="grid md:grid-cols-3 gap-5">
    {[
      { s: "3 sesiones", d: "-10%" },
      { s: "5 sesiones", d: "-20%" },
      { s: "10 sesiones", d: "-30%" },
    ].map((item) => (
      <motion.div
        key={item.s}
        variants={{
          hidden: {
            opacity: 0,
            y: 24,
            filter: "blur(8px)",
            scale: 0.96,
          },
          visible: {
            opacity: 1,
            y: 0,
            filter: "blur(0px)",
            scale: 1,
          },
        }}
        transition={{
          duration: 0.9,
          ease: [0.22, 1, 0.36, 1],
        }}
        className="group rounded-[28px] bg-[#F8F5F2]/90 border border-white/70 backdrop-blur-md p-7 overflow-hidden relative"
      >
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition duration-700 bg-[radial-gradient(circle_at_top_right,rgba(216,162,133,.18),transparent_55%)]" />

        <p className="relative text-[15px] tracking-[0.08em] uppercase text-[#8A7C72]">
          {item.s}
        </p>

        <motion.p
          initial={{ scale: 0.92 }}
          whileInView={{ scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative mt-6 text-[86px] leading-none tracking-[-0.08em] text-[#C97864]"
          style={{ fontFamily: "Satoshi" }}
        >
          {item.d}
        </motion.p>

        <div className="relative mt-8 h-px bg-gradient-to-r from-[#D8A285]/60 to-transparent" />
      </motion.div>
    ))}
  </div>

  <p className="mt-8 text-[15px] text-[#7A6B60]">
    Disponible para cualquier protocolo.
  </p>
</motion.div>
        <div className="flex justify-center mb-8">
  <button
    onClick={() => setShowInfo(true)}
    className="w-6 h-6 rounded-full border border-[#DBA997] flex items-center justify-center text-[11px] text-[#CE8273] hover:bg-[#B98B72]/10 transition-all"
    style={{ fontFamily: "satoshi" }}
  >
    i
  </button>
</div>

{showInfo && (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm">
    <div className="max-w-md rounded-[28px] bg-[#F7F3EF] p-8 shadow-xl">

      <button
        onClick={() => setShowInfo(false)}
        className="float-right text-[#B98B72]"
      >
        ✕
      </button>

      <h3
        className="mb-6 text-[18px] text-[#B98B72]"
        style={{ fontFamily: "satoshi" }}
      >
        información antes de hacer un protocolo
      </h3>

      <div className="space-y-4 text-sm text-[#5E534A] leading-relaxed">

        <p>• El PLAN LIBRE está destinado a usuarios que deciden realizar el protocolo sin asesoramiento ni seguimiento profesional continuado.</p>
        
        <p>• Al contratar el PLAN LIBRE, el usuario asume la responsabilidad de seguir las indicaciones proporcionadas y de comunicar cualquier circunstancia que pueda afectar a la seguridad del tratamiento.</p>

        <p>• the<strong>skin</strong>fix™ no podrá responsabilizarse de los resultados obtenidos con el PLAN LIBRE ni de posibles reacciones derivadas del incumplimiento de las recomendaciones facilitadas o de la ausencia de diagnóstico o seguimiento profesional.</p>

        <p>• El protocolo recomendado se determinará durante el PLAN GUIADO o en the<strong>skin</strong>fix™<strong>CLUB</strong>.</p>

        <p>• El número de sesiones puede variar según las necesidades de cada caso.</p>

        <p>• La recomendación profesional podrá actualizarse según la evolución de la piel.</p>

      </div>

    </div>
  </div>
)}
      </div>
     

{/* TRATAMIENTOS CLÍNICO-TERAPÉUTICOS */}

<section className="mt-32">
  <div className="max-w-5xl mx-auto">

    {/* CABECERA */}

    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="text-center mb-14"
    >
      

      <h3
        className="mt-5 text-[42px] md:text-[54px] leading-[0.95] tracking-[-0.05em] text-[#111]"
        style={{ fontFamily: "Satoshi" }}
      >
        TRATAMIENTOS TERAPÉUTICOS
      </h3>

    </motion.div>

    {/* GRID */}

    <div className="grid md:grid-cols-2 gap-5">

      {[
        {
          title: "DLM",
          subtitle: "Drenaje Linfático Manual",
          text: "Favorece la circulación linfática y ayuda a reducir inflamación y retención de líquidos cuando existe una indicación terapéutica.",
          tag: "Recuperación · Inflamación",
          icon: Waves
        },
        {
          title: "DLMP",
          subtitle: "Drenaje Linfático Postquirúrgico",
          text: "Acompaña la recuperación tras procedimientos quirúrgicos favoreciendo una evolución más controlada del tejido.",
          tag: "Postoperatorio",
          icon: Droplet
        },
        {
          title: "Extracción de Milium",
          subtitle: "",
          text: "Eliminación precisa de pequeños quistes de queratina mediante una técnica controlada.",
          tag: "Precisión clínica",
          icon: Sparkles
        },
        {
          title: "Reducción de Acrocordones",
          subtitle: "",
          text: "Eliminación segura de pequeñas lesiones cutáneas cuando está clínicamente indicado.",
          tag: "Lesiones benignas",
          icon: CircleDot
        },
        {
          title: "Kinesio Facial",
          subtitle: "",
          text: "Vendaje terapéutico que acompaña la recuperación ayudando a modular tensión e inflamación.",
          tag: "Recuperación muscular",
          icon: Bandage
        },
        {
          title: "Face Cupping",
          subtitle: "",
          text: "Técnica manual orientada a estimular la circulación y favorecer el drenaje tisular.",
          tag: "Estimulación tisular",
          icon: CircleDot
        }
      ].map((item, i) => {
        const Icon = item.icon;

        return (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, delay: i * 0.05 }}
            className="group rounded-[28px] bg-[#F5F2EE] p-8 transition-all duration-300 hover:-translate-y-1 hover:bg-[#F6F1ED]"
          >
            <div className="flex items-center justify-between mb-7">

             

             

            </div>

            <h4
              className="text-[28px] leading-none tracking-[-0.04em] text-[#5E534A]"
              style={{ fontFamily: "Satoshi" }}
            >
              {item.title}
            </h4>

            {item.subtitle && (
              <p
                className="mt-2 text-[15px] text-[#5E534A]"
                style={{ fontFamily: "Satoshi" }}
              >
                {item.subtitle}
              </p>
            )}

            <p
              className="mt-5 text-[15px] leading-[1.8] text-[#B3A99D]"
              style={{ fontFamily: "Satoshi" }}
            >
              {item.text}
            </p>
          </motion.div>
        );
      })}
    </div>

  </div>
</section>

{/* FOOTER CTA */}

<section className="mt-8 mb-8">
  <div className="max-w-[1350px] mx-auto px-8">
    <div className="rounded-[8px] bg-[#F7F4F1] px-20 py-12">

      <div className="mt-12 flex justify-center">
        <button
  className="
    rounded-full
    bg-[#C69178]
    px-12
    py-4
    text-[13px]
    font-medium
    uppercase
    tracking-[0.25em]
    text-white
    border
    border-white/20
    transition-all
    duration-300
    ease-out
    shadow-[inset_0_1px_0_rgba(255,255,255,0.18),0_14px_35px_rgba(94,74,58,0.18)]
    hover:bg-[#DBA185]
    hover:-translate-y-[2px]
    hover:shadow-[inset_0_1px_0_rgba(255,255,255,0.25),0_22px_45px_rgba(94,74,58,0.28)]
  "
>
    ELEGIR PLAN
  </button>
      </div>

      <div
  className="mt-20 pt-8 flex items-center justify-between text-[13px] tracking-[0.15em] text-[#8E847F]"
  style={{
    borderTop: "3px solid rgba(255,255,255,.75)",
  }}
>

        <Image
           src="/newfavicon.png"
           alt="the skin fix"
           width={42}
           height={42}
           className="opacity-90"
         />

        <div className="flex gap-10">

          <a
            href="/diagnostico"
            className="uppercase tracking-[0.18em] hover:opacity-70 transition"
          >
            DIAGNÓSTICO
          </a>

          <a
            href="/protocolo"
            className="uppercase tracking-[0.18em] text-[#000000] hover:opacity-70 transition"
          >
            PROTOCOLO
          </a>

          <a
            href="/seguimiento"
            className="uppercase tracking-[0.18em] hover:opacity-70 transition"
          >
            SEGUIMIENTO
          </a>

        </div>

      </div>

    </div>
  </div>
</section>
    </main>
  );
}
