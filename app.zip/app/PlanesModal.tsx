"use client";

import { motion } from "framer-motion";

type PlanesModalProps = {
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;

  showTerms: boolean;
  setShowTerms: React.Dispatch<React.SetStateAction<boolean>>;

  showPrice1: boolean;
  setShowPrice1: React.Dispatch<React.SetStateAction<boolean>>;

  showPrice2: boolean;
  setShowPrice2: React.Dispatch<React.SetStateAction<boolean>>;

  showPrice3: boolean;
  setShowPrice3: React.Dispatch<React.SetStateAction<boolean>>;

  position: number;
  positionGuiado: number;
  positionClub: number;

  handleMove: any;
  handleEnd: any;
  handleStart: any;

  handleMoveGuiado: any;
  handleEndGuiado: any;
  handleStartGuiado: any;

  handleMoveClub: any;
  handleEndClub: any;
  handleStartClub: any;
};

export default function PlanesModal({
  open,
  setOpen,

  showTerms,
  setShowTerms,

  showPrice1,
    setShowPrice1,

  showPrice2,
  setShowPrice2,

  showPrice3,
  setShowPrice3,

  position,
  positionGuiado,
  positionClub,

  handleMove,
  handleEnd,
  handleStart,

  handleMoveGuiado,
  handleEndGuiado,
  handleStartGuiado,

  handleMoveClub,
  handleEndClub,
  handleStartClub,
}: PlanesModalProps) {
  if (!open) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 backdrop-blur-sm">

<div className="min-h-screen flex items-center justify-center px-4 pb-8">
          <div
className="relative w-full max-w-[1230px] max-h-[100vh] overflow-visible rounded-[12px] border border-[#F5EEE7]/15 px-8 py-6"            style={{
              backgroundImage: "url('/planes.jpeg')",
              backgroundSize: "cover",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
            }}
          >
                        {/* Luces */}

            <div
              className="absolute -top-40 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full blur-[180px]"
              style={{
                background: "rgba(255,246,236,.14)",
              }}
            />

            <div
              className="absolute top-10 right-[-150px] w-[500px] h-[500px] rounded-full blur-[140px]"
              style={{
                background: "rgba(215,198,180,.06)",
              }}
            />

            <div
              className="absolute bottom-[-100px] left-[-100px] w-[550px] h-[550px] rounded-full blur-[150px]"
              style={{
                background: "rgba(90,78,70,.05)",
              }}
            />

            {/* Oscurecedor */}

            <div
              className="absolute inset-0 rounded-[12px]"
              style={{
                overflow: "hidden",
                background:
                  "radial-gradient(circle at center, transparent 35%, rgba(0,0,0,.35) 100%)",
              }}
            />

            {/* Contenido */}

            <div className="relative z-10">
                              {/* Botón cerrar */}

              <button
                onClick={() => setOpen(false)}
                className="
                  absolute
                  top-6
                  right-6
                  text-[#999]
                  text-2xl
                  transition-opacity
                  hover:opacity-70
                "
              >
                ×
              </button>

              {/* Cabecera */}

              <div className="mx-auto max-w-3xl text-center pt-0 md:pt-2">

              </div>
                            {/* Grid */}

              <div
  className="
    mx-auto
    mt-10
    max-w-[1080px]
    grid
    gap-8
    justify-center
    overflow-visible
  "
  style={{
    gridTemplateColumns: "repeat(auto-fit, minmax(320px, 320px))",
    overflow: "visible",
  }}
>

                {/* ========================================================= */}
                {/* PLAN LIBRE                                                 */}
                {/* ========================================================= */}

                <div
                  className="
                    relative
                    mt-[4px]
                    w-[320px]
                    min-h-[500px]
                    rounded-[40px]
                    overflow-visible

                    border
                    border-[rgba(255,255,255,0.16)]

                    backdrop-blur-xl

                    bg-[linear-gradient(180deg,rgba(255,255,255,0.03)_0%,rgba(255,255,255,0.015)_30%,rgba(15,15,15,0.95)_100%)]

                    shadow-[0_12px_30px_rgba(0,0,0,0.18),inset_0_1px_0_rgba(255,255,255,0.05),inset_0_-70px_90px_rgba(0,0,0,0.45)]

                    p-6
                    flex
                    flex-col
                  "
                >
                                      {/* Precio lateral */}

                  <div
                    onClick={() => setShowPrice1(!showPrice1)}
                    className="
                      absolute
                      top-25
                      -right-6
                      h-14
                      bg-white
                      rounded-tr-xl
                      rounded-br-xl
                      cursor-pointer
                      flex
                      items-center
                      justify-center
                      overflow-hidden
                      transition-all
                      duration-300
                    "
                    style={{
                      width: showPrice1 ? "65px" : "24px",
                    }}
                  >
                    {showPrice1 && (
                      <span className="flex flex-col items-center text-black text-[12px] font-medium leading-none">
                        <span>precio</span>
                        <span>único</span>
                      </span>
                    )}
                  </div>

                  <div>

                    <h3
                      className="
                        text-center
                        mt-4
                        text-[28px]
                        md:text-[32px]
                        leading-[0.95]
                        tracking-[-0.03em]
                        uppercase
                        text-[#D2B79A]
                        [text-shadow:0_3px_14px_rgba(0,0,0,0.55)]
                      "
                      style={{
                        fontFamily: "satoshi",
                        fontWeight: 900,
                      }}
                    >
                      PLAN LIBRE
                    </h3>

                    <motion.p
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{
                        duration: 0.5,
                        delay: 0.8,
                        ease: [0.22, 1, 0.36, 1],
                      }}
                      className="
                        mt-4
                        text-center
                        text-[14px]
                        leading-relaxed
                        text-[#F2E8DD]
                      "
                    >
                      Para quien conoce su piel y sabe exactamente qué necesita.
                    </motion.p>
                                        <div className="flex justify-center py-4">
                      <div
                        className="h-px w-16"
                        style={{
                          background:
                            "linear-gradient(90deg, rgba(255,255,255,0), rgba(243,239,234,0.45), rgba(255,255,255,0))",
                        }}
                      />
                    </div>

                  </div>

                  <div className="space-y-3 flex-1">

                    <div className="flex items-start gap-3 text-[15px] text-[#ffffff]">
                      <span>✓</span>
                      <span>Acceso a protocolos</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#ffffff]">
                      <span>✓</span>
                      <span>Reserva directa</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#999] opacity-50">
                      <span>×</span>
                      <span>Análisis corneométrico</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#999] opacity-50">
                      <span>×</span>
                      <span>Seguimiento continuo</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#999] opacity-50">
                      <span>×</span>
                      <span>Prescripción dermocosmética</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#999] opacity-50">
                      <span>×</span>
                      <span>THE BOOST BAR™ (suplementos, nutrición, fitness)</span>
                    </div>

                  </div>

                  <div className="mt-auto pt-8">
                                        <button
                      id="plan-libre-slider"
                      onMouseMove={handleMove}
                      onMouseUp={handleEnd}
                      onMouseLeave={handleEnd}
                      onTouchMove={handleMove}
                      onTouchEnd={handleEnd}
                      className="
                        relative
                        w-full
                        h-12
                        rounded-full

                        bg-[#F7EFE7]/10
                        backdrop-blur-xl

                        border
                        border-white/15

                        shadow-[inset_0_1px_0_rgba(255,255,255,0.25),0_8px_24px_rgba(0,0,0,0.30)]

                        text-white
                        overflow-hidden
                        mt-8
                      "
                    >
                      <span
                        className="
                          absolute
                          inset-0
                          flex
                          items-center
                          justify-center
                          text-[11px]
                          uppercase
                          tracking-[0.2em]
                          pointer-events-none
                        "
                      >
                        Consultar disponibilidad
                      </span>

                      <div
                        onMouseDown={handleStart}
                        onTouchStart={handleStart}
                        style={{
                          transform: `translateX(${position}px) translateY(-50%)`,
                        }}
                        className="
                          absolute
                          left-2
                          top-1/2
                          w-10
                          h-10
                          rounded-full
                          bg-white/40
                          cursor-grab
                          shadow-md
                        "
                      />
                    </button>

                  </div>

                </div>

                {/* ========================================================= */}
                {/* PLAN GUIADO                                               */}
                {/* ========================================================= */}

                <div                   className="
                    relative
                    mt-[4px]
                    w-[320px]
                    min-h-[500px]
                    rounded-[40px]
                    overflow-visible

                    border
                    border-[rgba(255,255,255,0.16)]

                    backdrop-blur-xl

                    bg-[linear-gradient(180deg,rgba(255,255,255,0.03)_0%,rgba(255,255,255,0.015)_30%,rgba(15,15,15,0.95)_100%)]

                    shadow-[0_12px_30px_rgba(0,0,0,0.18),inset_0_1px_0_rgba(255,255,255,0.05),inset_0_-70px_90px_rgba(0,0,0,0.45)]

                    p-8
                    flex
                    flex-col
                  "
                >

                  {/* Precio lateral */}

                  <div
                    onClick={() => setShowPrice2(!showPrice2)}
                    className="
                      absolute
                      top-25
                      -right-6
                      h-14
                      bg-white
                      rounded-tr-xl
                      rounded-br-xl
                      cursor-pointer
                      flex
                      items-center
                      justify-center
                      overflow-hidden
                      transition-all
                      duration-300
                    "
                    style={{
                      width: showPrice2 ? "65px" : "24px",
                    }}
                  >
                    {showPrice2 && (
                      <span className="text-black text-[12px] font-medium">
                        +20€
                      </span>
                    )}
                  </div>

                  {/* Badge */}

                  <div
                    className="
                      absolute
                      -top-5
                      left-1/2
                      -translate-x-1/2
                                            px-5
                      py-2

                      rounded-full

                      bg-[#B4A99D]
                      border
                      border-[#D7CEC3]

                      text-[#FCFAF7]
                      text-[11px]
                      font-semibold
                      uppercase
                      tracking-[0.20em]

                      shadow-[0_8px_24px_rgba(0,0,0,0.18)]
                    "
                  >
                    Más elegido
                  </div>

                  <div>

                    <h3
                      className="
                        text-center
                        mt-4
                        text-[28px]
                        md:text-[32px]
                        leading-[0.95]
                        tracking-[-0.03em]
                        uppercase
                        text-[#D2B79A]
                        [text-shadow:0_3px_14px_rgba(0,0,0,0.55)]
                      "
                      style={{
                        fontFamily: "satoshi",
                        fontWeight: 900,
                      }}
                    >
                      PLAN GUIADO
                    </h3>

                    <motion.p
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{
                        duration: 0.5,
                        delay: 1.8,
                        ease: [0.22, 1, 0.36, 1],
                      }}
                      className="
                        mt-4
                        text-center
                        text-[14px]
                        leading-relaxed
                        text-[#F2E8DD]
                      "
                    >
                      Para quien busca una orientación profesional antes de
                      empezar.
                    </motion.p>
                                        <div className="flex justify-center py-4">
                      <div
                        className="h-px w-16"
                        style={{
                          background:
                            "linear-gradient(90deg, rgba(255,255,255,0), rgba(243,239,234,0.45), rgba(255,255,255,0))",
                        }}
                      />
                    </div>

                  </div>

                  <div className="space-y-3 flex-1">

                    <div className="flex items-start gap-3 text-[15px] text-[#ffffff]">
                      <span>✓</span>
                      <span>Acceso a protocolos</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#ffffff]">
                      <span>✓</span>
                      <span>Reserva directa</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#ffffff]">
                      <span>✓</span>
                      <span>Análisis corneométrico</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#999] opacity-50">
                      <span>×</span>
                      <span>Seguimiento continuo</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#999] opacity-50">
                      <span>×</span>
                      <span>Prescripción dermocosmética</span>
                    </div>

                    <div className="flex items-start gap-3 text-[15px] text-[#999] opacity-50">
                      <span>×</span>
                      <span>THE BOOST BAR™ (suplementos, nutrición, fitness)</span>
                    </div>

                  </div>

                  <div className="mt-auto pt-8">
                                        <button
                      id="plan-guiado-slider"
                      onMouseMove={handleMoveGuiado}
                      onMouseUp={handleEndGuiado}
                      onMouseLeave={handleEndGuiado}
                      onTouchMove={handleMoveGuiado}
                      onTouchEnd={handleEndGuiado}
                      className="
                        relative
                        w-full
                        h-12
                        rounded-full

                        bg-[#F7EFE7]/10
                        backdrop-blur-xl

                        border
                        border-white/15

                        shadow-[inset_0_1px_0_rgba(255,255,255,0.25),0_8px_24px_rgba(0,0,0,0.30)]

                        text-white
                        overflow-hidden
                        mt-8
                      "
                    >
                      <span
                        className="
                          absolute
                          inset-0
                          flex
                          items-center
                          justify-center
                          text-[11px]
                          uppercase
                          tracking-[0.2em]
                          pointer-events-none
                        "
                      >
                        Consultar disponibilidad
                      </span>

                      <div
                        onMouseDown={handleStartGuiado}
                        onTouchStart={handleStartGuiado}
                        style={{
                          transform: `translateX(${positionGuiado}px) translateY(-50%)`,
                        }}
                        className="
                          absolute
                          left-2
                          top-1/2
                          w-10
                          h-10
                          rounded-full
                          bg-white/40
                          cursor-grab
                          shadow-md
                        "
                      />
                    </button>

                  </div>

                </div>

                {/* ========================================================= */}
                {/* CLUB                                                      */}
                {/* ========================================================= */}

                <div
                  className="club-card mt-[4px] w-[320px] min-h-[500px] relative overflow-visible p-8 flex flex-col"
                >
                                      {/* Precio lateral */}

                  <div
                    onClick={() => setShowPrice3(!showPrice3)}
                    className="
                      absolute
                      top-25
                      -right-6
                      h-14
                      bg-white
                      rounded-tr-xl
                      rounded-br-xl
                      cursor-pointer
                      flex
                      items-center
                      justify-center
                      overflow-hidden
                      transition-all
                      duration-300
                    "
                    style={{
                      width: showPrice3 ? "65px" : "24px",
                    }}
                  >
                    {showPrice3 && (
                      <span className="text-black text-[12px] font-medium">
                        50€
                      </span>
                    )}
                  </div>

                  {/* Badge */}

                  <div
                    className="
                      absolute
                      -top-5
                      left-1/2
                      -translate-x-1/2
                                            px-5
                      py-2

                      rounded-full

                      bg-[#B4A99D]
                      border
                      border-[#D7CEC3]

                      text-[#FCFAF7]
                      text-[11px]
                      font-semibold
                      uppercase
                      tracking-[0.20em]

                      shadow-[0_8px_24px_rgba(0,0,0,0.18)]
                    "
                  >
                    Más completo
                  </div>

                  <div>

                    <h3
                      className="
                        club-gold
                        text-center
                        mt-4
                        text-[28px]
                        md:text-[32px]
                        leading-[0.95]
                        tracking-[-0.03em]
                      "
                      style={{
                        fontFamily: "satoshi",
                        fontWeight: 900,
                      }}
                    >
                      CLUB
                    </h3>

                    <motion.p
                                          initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{
                        duration: 0.5,
                        delay: 2.7,
                        ease: [0.22, 1, 0.36, 1],
                      }}
                      className="
                        mt-5
                        text-center
                        text-[14px]
                        leading-relaxed
                        text-[#F2E8DD]
                      "
                    >
                      Para quien desea acompañamiento continuo + beneficios.
                    </motion.p>

                    <div className="flex justify-center py-4">
                      <div
                        className="h-px w-16"
                        style={{
                          background:
                            "linear-gradient(90deg, rgba(255,255,255,0), rgba(243,239,234,0.45), rgba(255,255,255,0))",
                        }}
                      />
                    </div>

                  </div>

                  <div className="space-y-3 flex-1">

                    <div className="flex items-start gap-3 text-[#ffffff] text-[15px]">
                      <span>✓</span>
                      <span>Acceso a protocolos</span>
                    </div>

                    <div className="flex items-start gap-3 text-[#ffffff] text-[15px]">
                      <span>✓</span>
                      <span>Reserva directa con prioridad</span>
                    </div>

                    <div className="flex items-start gap-3 text-[#ffffff] text-[15px]">
                      <span>✓</span>
                      <span>Análisis corneométrico</span>
                    </div>

                    <div className="flex items-start gap-3 text-[#ffffff] text-[15px]">
                      <span>✓</span>
                      <span>Seguimiento continuo</span>
                    </div>

                    <div className="flex items-start gap-3 text-[#ffffff] text-[15px]">
                      <span>✓</span>
                      <span>Prescripción dermocosmética</span>
                    </div>
                                        <div className="flex items-start gap-3 text-[#ffffff] text-[15px]">
                      <span>✓</span>
                      <span>THE BOOST BAR™ (suplementos, nutrición, fitness)</span>
                    </div>

                  </div>

                  <div className="mt-auto pt-8">

                    <button
                      id="club-slider"
                      onMouseMove={handleMoveClub}
                      onMouseUp={handleEndClub}
                      onMouseLeave={handleEndClub}
                      onTouchMove={handleMoveClub}
                      onTouchEnd={handleEndClub}
                      className="
                        relative
                        w-full
                        h-12
                        rounded-full

                        bg-[#F7EFE7]/10
                        backdrop-blur-xl

                        border
                        border-white/15

                        shadow-[inset_0_1px_0_rgba(255,255,255,0.25),0_8px_24px_rgba(0,0,0,0.30)]

                        text-white
                        overflow-hidden
                        mt-8
                      "
                    >
                      <span
                        className="
                          absolute
                          inset-0
                          flex
                          items-center
                          justify-center
                          text-[11px]
                          uppercase
                          tracking-[0.2em]
                          pointer-events-none
                        "
                      >
                        Consultar disponibilidad
                      </span>

                      <div
                        onMouseDown={handleStartClub}
                        onTouchStart={handleStartClub}
                        style={{
                          transform: `translateX(${positionClub}px) translateY(-50%)`,
                        }}
                        className="
                          absolute
                          left-2
                          top-1/2
                          w-10
                          h-10
                          rounded-full
                          bg-white/40
                          cursor-grab
                          shadow-md
                        "
                      />
                    </button>

                  </div>

                </div>
                              </div>

              {/* Información adicional */}

              <div className="mt-1 flex justify-center">

                <button
                  onClick={() => setShowTerms(true)}
                  className="
                    w-7
                    h-7

                    rounded-full

                    border
                    border-[#B98B72]

                    text-[#B98B72]

                    flex
                    items-center
                    justify-center

                    text-[12px]

                    opacity-90
                    hover:opacity-100

                    transition-all
                  "
                >
                  i
                </button>

              </div>

              {showTerms && (

                <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm">

                  <div className="max-w-md rounded-[28px] bg-[#F7F3EF] p-8 shadow-xl">

                    <button
                      onClick={() => setShowTerms(false)}
                      className="float-right text-[#8B8072]"
                    >
                      ×
                    </button>

                    <h3 className="mb-4 text-center text-[26px] text-[#B98B72]">
                      información adicional
                    </h3>

                    <div className="space-y-3 text-sm leading-relaxed text-[#5E534A]">

                      <p>
                        • Los <em>planes de recuperación</em> pueden modificarse
                        en cualquier momento, siempre que se solicite con la
                        antelación suficiente para su gestión y esta quede
                        confirmada.
                      </p>

                      <p>
                        • Los <em>protocolos</em> se presupuestan de forma
                        independiente a los planes de recuperación.
                      </p>

                      <p>
                        • El PLAN LIBRE incluye exclusivamente el protocolo
                        seleccionado, es decir, el protocolo BASE.
                      </p>

                      <p>
                        • El PLAN GUIADO añade un coste inicial por asesoría,
                        independiente al coste del protocolo.
                      </p>
                                            <p>
                        • the<strong>skin</strong>fix CLUB es un sistema de
                        membresía mensual en la que el profesional realizará los
                        ajustes necesarios para acompañar la evolución de cada
                        caso.
                      </p>

                      <p>
                        • La <em>prescripción dermocosmética</em> está incluida
                        en the<strong>skin</strong>fix CLUB. Los productos
                        recomendados no están incluidos y deberán ser adquiridos
                        independientemente por el cliente.
                      </p>

                      <div className="mt-6 border-t border-[#B89B72]/20 pt-4 text-center">

                        <a
                          href="https://wa.me/34618820842"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="
                            text-[14px]
                            text-[#8A7B70]
                            transition-colors
                            hover:text-[#A6564D]
                          "
                        >
                          ¿Alguna duda? Contáctenos.
                        </a>

                      </div>

                    </div>

                  </div>

                </div>

              )}

            </div>

          </div>

        </div>

      </div>

    </>
  );

}